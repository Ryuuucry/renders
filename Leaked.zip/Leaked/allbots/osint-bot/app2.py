import telebot
import requests
import json

BOT_TOKEN = "8383101634:AAFm31aT2yYEyJEMgOFRURUF5QjyPaV4PQs"
bot = telebot.TeleBot(BOT_TOKEN, parse_mode="HTML")

API_URL = "https://998d677a6067.ngrok-free.app/index.cpp"
GROUP_ID = -1002297972850  # Your group ID
GROUP_LINK = "https://t.me/+ZFzifY5Df5o5NDVl"  # Your group link

# Stylish bold labels using Unicode characters
LABELS = {
    "number": "📞 𝗡𝘂𝗺𝗯𝗲𝗿",
    "name": "👤 𝗡𝗮𝗺𝗲",
    "father": "👨‍👦 𝗙𝗮𝘁𝗵𝗲𝗿",
    "address": "🏠 𝗔𝗱𝗱𝗿𝗲𝘀𝘀",
    "circle": "📍 𝗖𝗶𝗿𝗰𝗹𝗲",
    "alt": "🔗 𝗔𝗹𝘁",
    "aadhaar": "🆔 𝗔𝗮𝗱𝗵𝗮𝗮𝗿",
    "vpa": "💳 𝗩𝗣𝗔",
    "ifsc": "🏦 𝗜𝗙𝗦𝗖",
    "bank": "🏛️ 𝗕𝗮𝗻𝗸",
    "branch": "🏢 𝗕𝗿𝗮𝗻𝗰𝗵",
    "state": "🗺️ 𝗦𝘁𝗮𝘁𝗲",
    "district": "📍 𝗗𝗶𝘀𝘁𝗿𝗶𝗰𝘁",
    "vehicle": "🚗 𝗩𝗲𝗵𝗶𝗰𝗹𝗲",
    "model": "🔧 𝗠𝗼𝗱𝗲𝗹",
    "owner": "👤 𝗢𝘄𝗻𝗲𝗿",
    "reg_date": "📅 𝗥𝗲𝗴. 𝗗𝗮𝘁𝗲",
    "fuel": "⛽ 𝗙𝘂𝗲𝗹",
    "engine": "⚙️ 𝗘𝗻𝗴𝗶𝗻𝗲",
    "chassis": "🔩 𝗖𝗵𝗮𝘀𝘀𝗶𝘀",
    "challan": "📋 𝗖𝗵𝗮𝗹𝗹𝗮𝗻",
    "violation": "⚠️ 𝗩𝗶𝗼𝗹𝗮𝘁𝗶𝗼𝗻",
    "amount": "💰 𝗔𝗺𝗼𝘂𝗻𝘁",
    "date": "📅 𝗗𝗮𝘁𝗲",
    "type": "📝 𝗧𝘆𝗽𝗲",
    "status": "✅ 𝗦𝘁𝗮𝘁𝘂𝘀",
    "contact": "📞 𝗖𝗼𝗻𝘁𝗮𝗰𝘁",
    "micr": "🔢 𝗠𝗜𝗖𝗥",
    "city": "🏙️ 𝗖𝗶𝘁𝘆",
    "centre": "🏛️ 𝗖𝗲𝗻𝘁𝗿𝗲",
    "neft": "💸 𝗡𝗘𝗙𝗧",
    "imps": "⚡ 𝗜𝗠𝗣𝗦",
    "rtgs": "🏦 𝗥𝗧𝗚𝗦",
    "swift": "🌐 𝗦𝗪𝗜𝗙𝗧",
    "iso": "🌍 𝗜𝗦𝗢",
    "bankcode": "🏦 𝗕𝗮𝗻𝗸 𝗖𝗼𝗱𝗲",
}


def is_user_member(user_id):
    """Check if user is a member of the required group"""
    try:
        member_status = bot.get_chat_member(GROUP_ID, user_id).status
        return member_status in ['member', 'administrator', 'creator']
    except:
        return False


def clean_address(address: str) -> str:
    """Clean address by replacing !! and ! with commas"""
    if not address:
        return "N/A"
    return address.replace("!!", ", ").replace("!", ", ")


def fetch_number_details(number, visited=None):
    """Fetch details + recursively fetch alt numbers"""
    if visited is None:
        visited = set()

    number = number[-10:]
    if number in visited:
        return []

    visited.add(number)

    try:
        url = f"{API_URL}?key=dark&number={number}"
        r = requests.get(url, timeout=10)
        data = r.json().get("data", [])
    except Exception as e:
        return [{"error": str(e)}]

    results = []
    for item in data:
        results.append({
            "mobile": item.get("mobile", "N/A"),
            "name": item.get("name", "N/A"),
            "fname": item.get("fname", "N/A"),
            "address": clean_address(item.get("address", "N/A")),
            "circle": item.get("circle", "N/A"),
            "alt": item.get("alt", "N/A"),
            "aadhaar": item.get("id", "N/A"),
        })

        # Recursive alt lookup
        alt = item.get("alt", "")
        if alt and alt.isdigit():
            alt_num = alt[-10:]
            if alt_num not in visited:
                results.extend(fetch_number_details(alt_num, visited))

    return results


def fetch_aadhaar_details(aadhaar):
    """Fetch details by Aadhaar number"""
    try:
        url = f"{API_URL}?key=dark&aadhaar={aadhaar}"
        r = requests.get(url, timeout=10)
        data = r.json().get("data", [])
    except Exception as e:
        return [{"error": str(e)}]

    results = []
    for item in data:
        results.append({
            "mobile": item.get("mobile", "N/A"),
            "name": item.get("name", "N/A"),
            "fname": item.get("fname", "N/A"),
            "address": clean_address(item.get("address", "N/A")),
            "circle": item.get("circle", "N/A"),
            "alt": item.get("alt", "N/A"),
            "aadhaar": item.get("id", "N/A"),
        })

    return results


def fetch_upi_details(upi):
    """Fetch UPI details"""
    try:
        url = f"{API_URL}?key=dark&upi={upi}"
        r = requests.get(url, timeout=10)
        data = r.json()
    except Exception as e:
        return {"error": str(e)}

    return data


def fetch_vehicle_details(vehicle):
    """Fetch vehicle details"""
    try:
        url = f"{API_URL}?key=dark&vehicle={vehicle}"
        r = requests.get(url, timeout=10)
        data = r.json()
    except Exception as e:
        return {"error": str(e)}

    return data


def format_phone_results(results):
    """Format phone results in a stylish profile card format"""
    blocks = []
    for item in results:
        if "error" in item:
            blocks.append(f"❌ Error fetching: <code>{item['error']}</code>")
            continue

        text = (
            "━━━━━━━━━━━━━━━━━━━━\n"
            f"{LABELS['number']}: <code>{item['mobile']}</code>\n"
            f"{LABELS['name']}: <code>{item['name']}</code>\n"
            f"{LABELS['father']}: <code>{item['fname']}</code>\n"
            f"{LABELS['address']}: <code>{item['address']}</code>\n"
            f"{LABELS['circle']}: <code>{item['circle']}</code>\n"
            f"{LABELS['alt']}: <code>{item['alt']}</code>\n"
            f"{LABELS['aadhaar']}: <code>{item['aadhaar']}</code>\n"
            "━━━━━━━━━━━━━━━━━━━━"
        )
        blocks.append(text)

    return "\n\n".join(blocks)


def format_aadhaar_results(results):
    """Format Aadhaar results in a stylish profile card format"""
    blocks = []
    for item in results:
        if "error" in item:
            blocks.append(f"❌ Error fetching: <code>{item['error']}</code>")
            continue

        text = (
            "━━━━━━━━━━━━━━━━━━━━\n"
            f"{LABELS['aadhaar']}: <code>{item['aadhaar']}</code>\n"
            f"{LABELS['name']}: <code>{item['name']}</code>\n"
            f"{LABELS['father']}: <code>{item['fname']}</code>\n"
            f"{LABELS['address']}: <code>{item['address']}</code>\n"
            f"{LABELS['number']}: <code>{item['mobile']}</code>\n"
            f"{LABELS['circle']}: <code>{item['circle']}</code>\n"
            f"{LABELS['alt']}: <code>{item['alt']}</code>\n"
            "━━━━━━━━━━━━━━━━━━━━"
        )
        blocks.append(text)

    return "\n\n".join(blocks)


def format_upi_results(data):
    """Format UPI results in a stylish card format"""
    if "error" in data:
        return f"❌ Error fetching: <code>{data['error']}</code>"

    ifsc_info = data.get("ifsc_info", {})

    text = (
        "💳 𝗨𝗣𝗜 𝗗𝗲𝘁𝗮𝗶𝗹𝘀\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        f"{LABELS['type']}: <code>{data.get('type', 'N/A')}</code>\n"
        f"{LABELS['name']}: <code>{data.get('name', 'N/A')}</code>\n"
        f"{LABELS['vpa']}: <code>{data.get('vpa', 'N/A')}</code>\n"
        f"{LABELS['ifsc']}: <code>{data.get('ifsc', 'N/A')}</code>\n"
        f"{LABELS['status']}: <code>{data.get('beneficiary_state', 'N/A')}</code>\n"
    )

    if ifsc_info:
        text += "\n🏦 𝗕𝗮𝗻𝗸 𝗗𝗲𝘁𝗮𝗶𝗹𝘀\n━━━━━━━━━━━━━━━━━━━━\n"
        for key, label in [
            ("BANK", LABELS["bank"]),
            ("BANKCODE", LABELS["bankcode"]),
            ("BRANCH", LABELS["branch"]),
            ("ADDRESS", LABELS["address"]),
            ("CONTACT", LABELS["contact"]),
            ("STATE", LABELS["state"]),
            ("DISTRICT", LABELS["district"]),
            ("CITY", LABELS["city"]),
            ("CENTRE", LABELS["centre"]),
            ("MICR", LABELS["micr"]),
            ("ISO3166", LABELS["iso"]),
            ("IFSC", LABELS["ifsc"]),
        ]:
            text += f"{label}: <code>{ifsc_info.get(key, 'N/A')}</code>\n"

        text += (
            f"{LABELS['neft']}: <code>{'Yes' if ifsc_info.get('NEFT') else 'No'}</code>\n"
            f"{LABELS['imps']}: <code>{'Yes' if ifsc_info.get('IMPS') else 'No'}</code>\n"
            f"{LABELS['rtgs']}: <code>{'Yes' if ifsc_info.get('RTGS') else 'No'}</code>\n"
            f"{LABELS['upi']}: <code>{'Yes' if ifsc_info.get('UPI') else 'No'}</code>\n"
            f"{LABELS['swift']}: <code>{ifsc_info.get('SWIFT', 'N/A')}</code>\n"
        )

    text += "━━━━━━━━━━━━━━━━━━━━"
    return text



def format_vehicle_results(data):
    """Format vehicle results in a stylish card format"""
    if "error" in data:
        return f"❌ Error fetching: <code>{data['error']}</code>"

    vehicle = data.get("vehicle_response", {})
    challan = data.get("challan_response", {})
    challan_data = challan.get("data", [])
    
    # Format vehicle info
    text = (
        "🚗 𝗩𝗲𝗵𝗶𝗰𝗹𝗲 𝗗𝗲𝘁𝗮𝗶𝗹𝘀\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        f"{LABELS['vehicle']}: <code>{vehicle.get('asset_number', 'N/A')}</code>\n"
        f"{LABELS['model']}: <code>{vehicle.get('make_model', 'N/A')}</code>\n"
        f"{LABELS['owner']}: <code>{vehicle.get('owner_name', 'N/A')}</code>\n"
        f"{LABELS['reg_date']}: <code>{vehicle.get('registration_date', 'N/A')}</code>\n"
        f"{LABELS['fuel']}: <code>{vehicle.get('fuel_type', 'N/A')}</code>\n"
        f"{LABELS['engine']}: <code>{vehicle.get('engine_number', 'N/A')}</code>\n"
        f"{LABELS['chassis']}: <code>{vehicle.get('chassis_number', 'N/A')}</code>\n"
        f"{LABELS['address']}: <code>{vehicle.get('permanent_address', 'N/A')}</code>\n"
        f"📅 Registration Year: <code>{vehicle.get('registration_year', 'N/A')}</code>\n"
        f"📍 Registration Address: <code>{vehicle.get('registration_address', 'N/A')}</code>\n"
        f"🏭 Make: <code>{vehicle.get('make_name', 'N/A')}</code>\n"
        f"🔄 Vehicle Type: <code>{vehicle.get('vehicle_type', 'N/A')}</code>\n"
    )
    
    # Add challan info if available
    if challan_data:
        text += "\n⚠️ 𝗖𝗵𝗮𝗹𝗹𝗮𝗻 𝗗𝗲𝘁𝗮𝗶𝗹𝘀\n━━━━━━━━━━━━━━━━━━━━\n"
        for i, challan_item in enumerate(challan_data[:3]):  # Show max 3 challans
            violations = challan_item.get("violations", {})
            text += (
                f"{LABELS['challan']}: <code>{challan_item.get('number', 'N/A')}</code>\n"
                f"{LABELS['violation']}: <code>{violations.get('details', [{}])[0].get('offence', 'N/A')}</code>\n"
                f"{LABELS['amount']}: <code>{violations.get('amount', 'N/A')}</code>\n"
                f"{LABELS['date']}: <code>{violations.get('date', 'N/A')}</code>\n"
                f"📍 Location: <code>{violations.get('location', 'N/A')}</code>\n"
                f"📊 Status: <code>{challan_item.get('challan_status', 'N/A')}</code>\n"
            )
            if i < len(challan_data[:3]) - 1:
                text += "━━━━━━━━━━━━━━━━━━━━\n"
    
    text += "━━━━━━━━━━━━━━━━━━━━"
    
    return text


@bot.message_handler(commands=['start'])
def send_welcome(message):
    markup = telebot.types.InlineKeyboardMarkup()
    dev_btn = telebot.types.InlineKeyboardButton("👨‍💻 Developer", url="https://t.me/YOUR_USERNAME")
    chan_btn = telebot.types.InlineKeyboardButton("📢 Channel", url="https://t.me/stormxvup")
    markup.row(dev_btn, chan_btn)

    text = (
        "<b>🤖 Multi-Info Bot</b>\n\n"
        "Available commands:\n"
        "• <b>/ph &lt;number&gt;</b> - Phone number lookup\n"
        "• <b>/aadhaar &lt;number&gt;</b> - Aadhaar lookup\n"
        "• <b>/upi &lt;vpa&gt;</b> - UPI/VPA lookup\n"
        "• <b>/vh &lt;number&gt;</b> - Vehicle lookup\n\n"
        "Example: <b>/ph 9026927714</b>"
    )
    bot.send_message(message.chat.id, text, reply_markup=markup)


def send_checking_message(message, query_type):
    """Send initial checking message"""
    return bot.reply_to(message, f"🔍 Checking {query_type}, please wait...")


@bot.message_handler(commands=['ph'])
def phone_lookup(message):
    # Check if user is a member of the group
    if not is_user_member(message.from_user.id):
        markup = telebot.types.InlineKeyboardMarkup()
        join_btn = telebot.types.InlineKeyboardButton("Join Our Group", url=GROUP_LINK)
        markup.add(join_btn)
        
        bot.reply_to(
            message, 
            "❌ You must join our group to use this bot.\n\n"
            "Please join our group and try again.",
            reply_markup=markup
        )
        return

    try:
        args = message.text.split(" ", 1)
        if len(args) < 2:
            bot.reply_to(message, "❌ Please provide a phone number.\nExample: <b>/ph 9026927714</b>")
            return

        raw_number = args[1].replace(" ", "").strip()
        number = raw_number[-10:]  # last 10 digits

        # Send initial "checking" message
        checking_msg = send_checking_message(message, "phone number")

        results = fetch_number_details(number)

        if not results:
            bot.edit_message_text(
                "⚠️ No data found for this number.",
                chat_id=checking_msg.chat.id,
                message_id=checking_msg.message_id
            )
            return

        formatted = format_phone_results(results)
        bot.edit_message_text(
            formatted,
            chat_id=checking_msg.chat.id,
            message_id=checking_msg.message_id
        )

    except Exception as e:
        # If we have a checking message, edit it, otherwise send a new message
        if 'checking_msg' in locals():
            bot.edit_message_text(
                f"❌ Error: <code>{e}</code>",
                chat_id=checking_msg.chat.id,
                message_id=checking_msg.message_id
            )
        else:
            bot.reply_to(message, f"❌ Error: <code>{e}</code>")


@bot.message_handler(commands=['aadhaar'])
def aadhaar_lookup(message):
    # Check if user is a member of the group
    if not is_user_member(message.from_user.id):
        markup = telebot.types.InlineKeyboardMarkup()
        join_btn = telebot.types.InlineKeyboardButton("Join Our Group", url=GROUP_LINK)
        markup.add(join_btn)
        
        bot.reply_to(
            message, 
            "❌ You must join our group to use this bot.\n\n"
            "Please join our group and try again.",
            reply_markup=markup
        )
        return

    try:
        args = message.text.split(" ", 1)
        if len(args) < 2:
            bot.reply_to(message, "❌ Please provide an Aadhaar number.\nExample: <b>/aadhaar 715515712061</b>")
            return

        aadhaar = args[1].replace(" ", "").strip()

        # Send initial "checking" message
        checking_msg = send_checking_message(message, "Aadhaar number")

        results = fetch_aadhaar_details(aadhaar)

        if not results:
            bot.edit_message_text(
                "⚠️ No data found for this Aadhaar number.",
                chat_id=checking_msg.chat.id,
                message_id=checking_msg.message_id
            )
            return

        formatted = format_aadhaar_results(results)
        bot.edit_message_text(
            formatted,
            chat_id=checking_msg.chat.id,
            message_id=checking_msg.message_id
        )

    except Exception as e:
        # If we have a checking message, edit it, otherwise send a new message
        if 'checking_msg' in locals():
            bot.edit_message_text(
                f"❌ Error: <code>{e}</code>",
                chat_id=checking_msg.chat.id,
                message_id=checking_msg.message_id
            )
        else:
            bot.reply_to(message, f"❌ Error: <code>{e}</code>")


@bot.message_handler(commands=['upi'])
def upi_lookup(message):
    # Check if user is a member of the group
    if not is_user_member(message.from_user.id):
        markup = telebot.types.InlineKeyboardMarkup()
        join_btn = telebot.types.InlineKeyboardButton("Join Our Group", url=GROUP_LINK)
        markup.add(join_btn)
        
        bot.reply_to(
            message, 
            "❌ You must join our group to use this bot.\n\n"
            "Please join our group and try again.",
            reply_markup=markup
        )
        return

    try:
        args = message.text.split(" ", 1)
        if len(args) < 2:
            bot.reply_to(message, "❌ Please provide a UPI/VPA.\nExample: <b>/upi fasterversionofme@okicici</b>")
            return

        upi = args[1].strip()

        # Send initial "checking" message
        checking_msg = send_checking_message(message, "UPI/VPA")

        result = fetch_upi_details(upi)

        if "error" in result:
            bot.edit_message_text(
                f"⚠️ Error: {result['error']}",
                chat_id=checking_msg.chat.id,
                message_id=checking_msg.message_id
            )
            return

        formatted = format_upi_results(result)
        bot.edit_message_text(
            formatted,
            chat_id=checking_msg.chat.id,
            message_id=checking_msg.message_id
        )

    except Exception as e:
        # If we have a checking message, edit it, otherwise send a new message
        if 'checking_msg' in locals():
            bot.edit_message_text(
                f"❌ Error: <code>{e}</code>",
                chat_id=checking_msg.chat.id,
                message_id=checking_msg.message_id
            )
        else:
            bot.reply_to(message, f"❌ Error: <code>{e}</code>")


@bot.message_handler(commands=['vh'])
def vehicle_lookup(message):
    # Check if user is a member of the group
    if not is_user_member(message.from_user.id):
        markup = telebot.types.InlineKeyboardMarkup()
        join_btn = telebot.types.InlineKeyboardButton("Join Our Group", url=GROUP_LINK)
        markup.add(join_btn)
        
        bot.reply_to(
            message, 
            "❌ You must join our group to use this bot.\n\n"
            "Please join our group and try again.",
            reply_markup=markup
        )
        return

    try:
        args = message.text.split(" ", 1)
        if len(args) < 2:
            bot.reply_to(message, "❌ Please provide a vehicle number.\nExample: <b>/vh JK05F1806</b>")
            return

        vehicle = args[1].strip().upper()

        # Send initial "checking" message
        checking_msg = send_checking_message(message, "vehicle number")

        result = fetch_vehicle_details(vehicle)

        if "error" in result:
            bot.edit_message_text(
                f"⚠️ Error: {result['error']}",
                chat_id=checking_msg.chat.id,
                message_id=checking_msg.message_id
            )
            return

        formatted = format_vehicle_results(result)
        bot.edit_message_text(
            formatted,
            chat_id=checking_msg.chat.id,
            message_id=checking_msg.message_id
        )

    except Exception as e:
        # If we have a checking message, edit it, otherwise send a new message
        if 'checking_msg' in locals():
            bot.edit_message_text(
                f"❌ Error: <code>{e}</code>",
                chat_id=checking_msg.chat.id,
                message_id=checking_msg.message_id
            )
        else:
            bot.reply_to(message, f"❌ Error: <code>{e}</code>")


print("✅ Bot is running...")
bot.infinity_polling()
