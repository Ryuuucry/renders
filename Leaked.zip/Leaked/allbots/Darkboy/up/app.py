import time
import requests

URL = "https://darkboy-urdp.onrender.com/"

def send_request():
    try:
        response = requests.get(URL)
        print(f"Status Code: {response.status_code}")
        print(f"Response: {response.text}")
    except Exception as e:
        print(f"Error occurred: {e}")

if __name__ == "__main__":
    while True:
        send_request()
        time.sleep(200)  # wait 200 seconds before next request
