from telethon import TelegramClient

# Your API credentials (replace these with your actual values)                          API_ID = 29612794  # Replace with your actual API ID
API_HASH = '6edc1a58a202c9f6e62dc98466932bad'  # Replace with your actual API hash
API_ID = 29612794
# Session file name
SESSION_NAME = 'session_name'

# Initialize the client
client = TelegramClient(SESSION_NAME, API_ID, API_HASH)

async def main():
    await client.start()
    print("Logged in successfully!")

    me = await client.get_me()
    print(f"User: {me.first_name} (ID: {me.id})")

    await client.disconnect()

# Run the script
if __name__ == "__main__":
    client.loop.run_until_complete(main())
