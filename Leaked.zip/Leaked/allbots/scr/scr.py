import asyncio
import logging
import re
import time
import threading
from collections import defaultdict
from flask import Flask, jsonify

from telethon import TelegramClient
from telethon.tl.functions.messages import ImportChatInviteRequest, CheckChatInviteRequest
from telethon.tl.functions.channels import LeaveChannelRequest
from telethon.tl.types import PeerChannel
from telethon.errors import UserAlreadyParticipantError

# ==========================
# CONFIG
# ==========================
API_ID = 29612794
API_HASH = '6edc1a58a202c9f6e62dc98466932bad'
PHONE_NUMBER = '+918528234488'
API_KEY = 'waslost'

SCRAPE_RATE_LIMIT = 10  # seconds between scrapes
MAX_SCRAPE_COUNT = 200  # prevent abuse
# ==========================

client = None
telegram_ready = False
telegram_loop = None
last_scrape_time = 0

# Logging
logging.basicConfig(format='[%(levelname)s] %(message)s', level=logging.INFO)
logger = logging.getLogger(__name__)

# Regex pattern (16 digits | MM | YYYY | CVV)
CC_PATTERN = re.compile(r'\b\d{15,16}\|\d{2}\|\d{4}\|\d{3,4}\b')

# Flask app
app = Flask(__name__)


# --------------------------
# TELEGRAM INIT
# --------------------------
async def initialize_telegram():
    global client, telegram_ready
    try:
        client = TelegramClient('session_name', API_ID, API_HASH)
        await client.start(PHONE_NUMBER)
        me = await client.get_me()
        logger.info(f"Logged in as {me.first_name} (username: @{me.username})")
        telegram_ready = True
        return client
    except Exception as e:
        logger.error(f"Telegram init failed: {e}")
        raise


# --------------------------
# PROCESSING
# --------------------------
async def process_cc_info(cc_list):
    unique_ccs = set()
    cc_counts = defaultdict(int)

    for cc in cc_list:
        cc_number = cc.split('|')[0]
        cc_counts[cc_number] += 1
        unique_ccs.add(cc)

    return {
        'unique_ccs': sorted(list(unique_ccs)),
        'duplicates': sum(1 for count in cc_counts.values() if count > 1),
        'total_found': len(cc_list)
    }


# --------------------------
# SCRAPER
# --------------------------
async def scrape_channel(channel_identifier, num_messages):
    global last_scrape_time

    # Enforce rate limit
    now = time.time()
    if now - last_scrape_time < SCRAPE_RATE_LIMIT:
        wait_time = SCRAPE_RATE_LIMIT - (now - last_scrape_time)
        logger.info(f"Rate limit hit, sleeping {wait_time:.1f}s...")
        await asyncio.sleep(wait_time)

    try:
        channel = None
        joined_temp = False

        # Invite link
        if "t.me/+" in channel_identifier or "joinchat" in channel_identifier or channel_identifier.startswith("+"):
            invite_hash = channel_identifier.split("+")[-1]
            try:
                logger.info(f"Trying invite join: {invite_hash}")
                update = await client(ImportChatInviteRequest(invite_hash))
                channel = update.chats[0]
                joined_temp = True
            except UserAlreadyParticipantError:
                logger.info("Already participant, continuing...")
                channel = await client.get_entity(channel_identifier)
            except Exception as e:
                logger.error(f"Invite join failed: {e}")
                return None

        # Channel/group ID
        elif str(channel_identifier).lstrip("-").isdigit():
            channel = await client.get_entity(PeerChannel(int(channel_identifier)))

        # Public username
        else:
            channel = await client.get_entity(channel_identifier)

        # Scrape messages
        cc_list = []
        async for message in client.iter_messages(channel, limit=num_messages):
            if message.text:
                matches = CC_PATTERN.findall(message.text)
                cc_list.extend(matches)

        # Leave if joined temporarily
        if joined_temp and channel:
            try:
                logger.info("Leaving channel after scrape...")
                await client(LeaveChannelRequest(channel))
            except Exception as e:
                logger.warning(f"Failed to leave channel: {e}")

        last_scrape_time = time.time()
        return await process_cc_info(cc_list) if cc_list else None

    except Exception as e:
        logger.error(f"Scraping error: {e}")
        return None


# --------------------------
# FLASK ENDPOINT
# --------------------------
@app.route('/key=<key>/uname/<path:username>/<int:count>')
def scrape_endpoint(key, username, count):
    if key != API_KEY:
        return jsonify({'error': 'Invalid API key'}), 401

    if count <= 0 or count > MAX_SCRAPE_COUNT:
        return jsonify({'error': f'Count must be between 1 and {MAX_SCRAPE_COUNT}'}), 400

    if not telegram_ready or not client:
        return jsonify({'error': 'Telegram client not ready'}), 503

    try:
        future = asyncio.run_coroutine_threadsafe(scrape_channel(username, count), telegram_loop)
        result = future.result(timeout=300)

        if not result:
            return jsonify({'error': 'No CCs found or channel not accessible'}), 404

        return jsonify({
            'status': 'success',
            'channel': username,
            'messages_scraped': count,
            'unique_ccs': len(result['unique_ccs']),
            'duplicates_found': result['duplicates'],
            'total_found': result['total_found'],
            'cc_list': result['unique_ccs']
        })
    except Exception as e:
        logger.error(f"API error: {e}")
        return jsonify({'error': str(e)}), 500


# --------------------------
# THREAD MANAGEMENT
# --------------------------
def telegram_thread_func():
    global telegram_loop, client
    telegram_loop = asyncio.new_event_loop()
    asyncio.set_event_loop(telegram_loop)

    try:
        client = telegram_loop.run_until_complete(initialize_telegram())
        telegram_loop.run_forever()
    except Exception as e:
        logger.error(f"Telegram thread failed: {e}")
    finally:
        telegram_loop.close()


def run_flask():
    app.run(host='0.0.0.0', port=2233)


# --------------------------
# MAIN
# --------------------------
if __name__ == '__main__':
    # Start Telegram client thread
    telegram_thread = threading.Thread(target=telegram_thread_func, daemon=True)
    telegram_thread.start()

    # Wait for login
    while not telegram_ready:
        logger.info("Waiting for Telegram login...")
        time.sleep(1)

    # Run Flask
    run_flask()
