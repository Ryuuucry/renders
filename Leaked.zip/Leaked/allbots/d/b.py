import telebot
import requests

# === CONFIG ===
BOT_TOKEN = "7814605131:AAGYvyJtRm0EoEuni_Ol6_juLzdNHeSPVzc"   # put your bot token here
CF_API_TOKEN = "x1TNOzxq7bVOrAdpZQt0_votCkX7XOrVMZXNdQO6"  # from Cloudflare
ZONE_ID = "5b7b96cded3b9699e89d9eec3c015fa6"  # from Cloudflare
DOMAIN = "stormx.pw"  # your domain

bot = telebot.TeleBot(BOT_TOKEN)

# Temporary storage for user flow
user_data = {}

# === START COMMAND ===
@bot.message_handler(commands=['start'])
def start(message):
    bot.reply_to(
        message,
        "👋 Welcome!\n\n"
        "This bot will create subdomains on *stormx.pw*.\n\n"
        "➡️ Please enter the subdomain name you want (example: `darkk`)\n\n"
        "_Do not include the main domain, only the prefix._",
        parse_mode="Markdown"
    )
    bot.register_next_step_handler(message, get_subdomain)

# === STEP 1: GET SUBDOMAIN ===
def get_subdomain(message):
    subdomain = message.text.strip().lower()

    if "." in subdomain or len(subdomain) < 2:
        bot.reply_to(message, "❌ Invalid subdomain. Try again with a simple word (e.g., `darkk`).")
        return

    user_data[message.chat.id] = {"subdomain": subdomain}
    bot.reply_to(message, f"✅ Subdomain prefix saved: `{subdomain}`\n\n➡️ Now send me the IPv4 address (e.g., `1.2.3.4`).", parse_mode="Markdown")
    bot.register_next_step_handler(message, get_ipv4)

# === STEP 2: GET IPV4 ===
def get_ipv4(message):
    ip = message.text.strip()

    # Basic validation
    parts = ip.split(".")
    if len(parts) != 4 or not all(p.isdigit() and 0 <= int(p) <= 255 for p in parts):
        bot.reply_to(message, "❌ Invalid IPv4 format. Try again (e.g., `1.2.3.4`).")
        return

    user_data[message.chat.id]["ip"] = ip

    # Call Cloudflare API
    create_subdomain(message)

# === STEP 3: CREATE SUBDOMAIN VIA CLOUDFLARE ===
def create_subdomain(message):
    sub = user_data[message.chat.id]["subdomain"]
    ip = user_data[message.chat.id]["ip"]

    url = f"https://api.cloudflare.com/client/v4/zones/{ZONE_ID}/dns_records"
    headers = {"Authorization": f"Bearer {CF_API_TOKEN}", "Content-Type": "application/json"}
    data = {
        "type": "A",
        "name": f"{sub}.{DOMAIN}",
        "content": ip,
        "ttl": 1,
        "proxied": False
    }

    response = requests.post(url, headers=headers, json=data).json()

    if response.get("success"):
        bot.reply_to(
            message,
            f"🎉 Subdomain created!\n\n"
            f"🌐 Domain: `{sub}.{DOMAIN}`\n"
            f"📌 IPv4: `{ip}`\n"
            f"☁️ Proxy: OFF\n"
            f"⏱ TTL: Auto",
            parse_mode="Markdown"
        )
    else:
        error = response.get("errors", [{}])[0].get("message", "Unknown error")
        bot.reply_to(message, f"❌ Failed to create subdomain.\n\nError: {error}")

# === RUN BOT ===
print("🤖 Bot running...")
bot.infinity_polling()
